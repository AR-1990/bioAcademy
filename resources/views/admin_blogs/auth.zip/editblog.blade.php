@extends('admin.layouts.master')
@section('content')
    <link href="https://cdn.quilljs.com/1.0.0/quill.snow.css" rel="stylesheet" />
    <style>
        .main_container {
            margin-top: 70px !important;
            padding: 40px 10px;
            background-color: #fff;
            box-shadow: rgba(99, 99, 99, 0.2) 0px 2px 8px 0px;
            border-radius: 8px;
        }

        .input_fields {
            display: block;
            width: 100%;
            height: calc(1.5em + 0.75rem + 2px);
            padding: 0.375rem 0.75rem;
            font-size: 1rem;
            font-weight: 400;
            line-height: 1.5;
            color: #495057;
            background-color: #fff;
            background-clip: padding-box;
            border: 1px solid #ced4da;
            border-radius: 0.25rem;
            -webkit-transition: border-color .15s ease-in-out, -webkit-box-shadow .15s ease-in-out;
            transition: border-color .15s ease-in-out, -webkit-box-shadow .15s ease-in-out;
            transition: border-color .15s ease-in-out, box-shadow .15s ease-in-out;
            transition: border-color .15s ease-in-out, box-shadow .15s ease-in-out, -webkit-box-shadow .15s ease-in-out;
        }

        .input_fields:focus {
            background-color: #fefeff;
            border-color: #95a0f4;
            outline: none;
        }

        @media (max-width: 567px) {
            .update_btn {
                width: 100% !important;
            }
        }

        .dataTables_length {
            display: none
        }

        .dataTables_filter {
            display: none
        }

        .fa-trash,
        .fa-edit {
            font-size: 24px;
        }

        .fa-trash,
        .fa-edit:hover {
            cursor: pointer;
        }

        .fa-edit {
            margin-left: 15px;
        }

        .new_td {
            /* border: 1px solid red; */
            width: 50%;
            margin: 0 auto !important;
            display: block;
        }

        .icon_td {
            width: 20%;
        }

        .radio_design {}

        .bedroom_items {
            display: none !important;
        }


        /* image upload */


        /* input type file */


        .label_file {
            padding: 43px 30px;
            padding-bottom: 40px;
            /* background: red;  */
            display: table;
            color: #000 !important;
            background-color: #fafafa;
            cursor: pointer;
            border-radius: 5px;
            border: 1px dashed #d9d9d9;
            height: 0px;
            transition: 0.3s;
            /* background-color: #8dc63f; */
            box-sizing: border-box;
            overflow: hidden;
        }

        .label_file1 {
            padding: 43px 58px;
            padding-bottom: 38px;
            /* background: red;  */
            display: table;
            color: #000 !important;
            background-color: #fafafa;
            cursor: pointer;
            border-radius: 5px;
            border: 1px dashed #d9d9d9;
            height: 0px;
            transition: 0.3s;
            /* background-color: #8dc63f; */
            box-sizing: border-box;
            overflow: hidden;
            /* border: 1px solid red; */
        }

        .label_for_remove {
            padding: 53px 58px;
            display: none;
        }

        .label_file:hover {
            background-color: #fafafa;
            border: 1px dashed #0d6db7;
            cursor: pointer;
        }


        input[type="file"] {
            display: none;
        }

        #editor-container {
            height: 300px;
        }


        .box {
            display: block;
            min-width: 300px;
            max-width: 50%;
            height: 198px;
            margin: 10px;
            background-color: white;
            border-radius: 5px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.12), 0 1px 2px rgba(0, 0, 0, 0.24);
            transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
            overflow: hidden;
        }

        .upload-options {
            position: relative;
            height: 40px;
            background-color: cadetblue;
            cursor: pointer;
            overflow: hidden;
            text-align: center;
            transition: background-color ease-in-out 150ms;
        }

        .upload-options:hover {
            background-color: #7fb1b3;
        }

        .upload-options input {
            width: 0.1px;
            height: 0.1px;
            opacity: 0;
            overflow: hidden;
            position: absolute;
            z-index: -1;
        }

        .upload-options label {
            display: flex;
            align-items: center;
            width: 100%;
            height: 100%;
            font-weight: 400;
            text-overflow: ellipsis;
            white-space: nowrap;
            cursor: pointer;
            overflow: hidden;
        }

        .upload-options label::after {
            content: 'add';
            font-family: 'Material Icons';
            position: absolute;
            font-size: 2.5rem;
            color: rgba(230, 230, 230, 1);
            top: calc(75% - 2.5rem);
            left: calc(50% - 1.25rem);
            z-index: 0;
        }

        .upload-options label span {
            display: inline-block;
            width: 50%;
            height: 100%;
            text-overflow: ellipsis;
            white-space: nowrap;
            overflow: hidden;
            vertical-align: middle;
            text-align: center;
        }

        .upload-options label span:hover i.material-icons {
            color: lightgray;
        }

        .js--image-preview {
            height: 160px;
            width: 100%;
            position: relative;
            overflow: hidden;
            background-image: url('');
            background-color: white;
            background-position: center center;
            background-repeat: no-repeat;
            background-size: cover;
        }

        .js--image-preview::after {
            content: "photo_size_select_actual";
            font-family: 'Material Icons';
            position: relative;
            font-size: 4.5em;
            color: rgba(230, 230, 230, 1);
            top: calc(50% - 3rem);
            left: calc(50% - 2.25rem);
            z-index: 0;
        }

        .js--image-preview.js--no-default::after {
            display: none;
        }

        .js--image-preview:nth-child(2) {
            background-image: url('http://bastianandre.at/giphy.gif');
        }

        i.material-icons {
            transition: color 100ms ease-in-out;
            font-size: 2.25em;
            line-height: 55px;
            color: white;
            display: block;
        }

        .drop {
            display: block;
            position: absolute;
            background: rgba(95, 158, 160, 0.2);
            border-radius: 100%;
            transform: scale(0);
        }

        .animate {
            animation: ripple 0.4s linear;
        }

        @keyframes ripple {
            100% {
                opacity: 0;
                transform: scale(2.5);
            }
        }
    </style>
    <div class="main-content">
        <section class="section">
            <ul class="breadcrumb breadcrumb-style ">
                <li class="breadcrumb-item">
                    <h4 class="page-title m-b-0">Edit Blog</h4>
                </li>            
            </ul>
            <form  enctype="multipart/form-data" method="POST" > 
            <input type="hidden" name="_token" id="token" value="{{ csrf_token() }}">
                <input type="hidden" name="_token" id="id" value="{{$blog['id']}}">
                <div class="section-body mb-5">
                    <div class="row">
                        <div class="col-12 col-md-12 col-lg-12">
                            <div class="card">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <h5 class="my-2">Add Title</h5>
                                                <div class="input-group">
                                                    <input type="text" name="title" 
                                                        class="form-control phone-number"  name="title" id="title" value="{{$blog->title}}">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <div id="editor-container">
                                                    <div id="toolbar">
                                                        {!!$blog->content !!}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                 
                                    <div class="row">
                                        <div class="col-md-6">
                                            <h5 class="my-2">Upload New Image</h5>
                                            <div class="wrapper">
                                                <div class="box">
                                                    <div class="js--image-preview"></div>
                                                    <div class="upload-options">
                                                        <label>
                                                            <input type="file" class="image-upload" accept="image/*" name="cuctomeimage" id="cuctomeimage"/>
                                                        </label>
                                                    </div>
                                                </div>


                                            </div>
                                        </div>
                                   
                                        <div class="col-md-6">
                                            <h5 class="my-2">Current Image</h5>
                                            <div class="wrapper">
                                                <div class="box">                                             
                                                <img src="{{ asset('storage/' . $blog->image) }}" alt="current image">                                                                                             
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row  mb-5">
                                <div class="col-md-6">
                                    <button type="button" class="btn btn-dark" onclick="datapass();">Submit</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
    </div>
    </form>

    </section>
    </div>
@endsection
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
@push('script')
    <!-- Main Quill library -->
    <script src="//cdn.quilljs.com/1.3.6/quill.js"></script>
    <script src="//cdn.quilljs.com/1.3.6/quill.min.js"></script>

    <!-- Theme included stylesheets -->
    <link href="//cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
    <link href="//cdn.quilljs.com/1.3.6/quill.bubble.css" rel="stylesheet">

    <!-- Core build with no theme, formatting, non-essential modules -->
    <link href="//cdn.quilljs.com/1.3.6/quill.core.css" rel="stylesheet">
    <script src="//cdn.quilljs.com/1.3.6/quill.core.js"></script>
    <script src="https://cdn.quilljs.com/1.0.0/quill.js"></script>
    <script>
        var quill = new Quill('#editor-container', {
            modules: {
                toolbar: [
                    [{
                        header: [1, 2, false]
                    }],
                    ['bold', 'italic', 'underline'],
                    []
                ]
            },
            placeholder: 'Add ',
            theme: 'snow' // or 'bubble'
        });
    </script>
    {{-- image upload javascript --}}


    <script>
        function initImageUpload(box) {
            let uploadField = box.querySelector('.image-upload');

            uploadField.addEventListener('change', getFile);

            function getFile(e) {
                let file = e.currentTarget.files[0];
                checkType(file);
            }

            function previewImage(file) {
                let thumb = box.querySelector('.js--image-preview'),
                    reader = new FileReader();

                reader.onload = function() {
                    thumb.style.backgroundImage = 'url(' + reader.result + ')';
                }
                reader.readAsDataURL(file);
                thumb.className += ' js--no-default';
            }

            function checkType(file) {
                let imageType = /image.*/;
                if (!file.type.match(imageType)) {
                    throw 'Datei ist kein Bild';
                } else if (!file) {
                    throw 'Kein Bild gewählt';
                } else {
                    previewImage(file);
                }
            }

        }

        // initialize box-scope
        var boxes = document.querySelectorAll('.box');

        for (let i = 0; i < boxes.length; i++) {
            let box = boxes[i];
            initDropEffect(box);
            initImageUpload(box);
        }



        /// drop-effect
        function initDropEffect(box) {
            let area, drop, areaWidth, areaHeight, maxDistance, dropWidth, dropHeight, x, y;

            // get clickable area for drop effect
            area = box.querySelector('.js--image-preview');
            area.addEventListener('click', fireRipple);

            function fireRipple(e) {
                area = e.currentTarget
                // create drop
                if (!drop) {
                    drop = document.createElement('span');
                    drop.className = 'drop';
                    this.appendChild(drop);
                }
                // reset animate class
                drop.className = 'drop';

                // calculate dimensions of area (longest side)
                areaWidth = getComputedStyle(this, null).getPropertyValue("width");
                areaHeight = getComputedStyle(this, null).getPropertyValue("height");
                maxDistance = Math.max(parseInt(areaWidth, 10), parseInt(areaHeight, 10));

                // set drop dimensions to fill area
                drop.style.width = maxDistance + 'px';
                drop.style.height = maxDistance + 'px';

                // calculate dimensions of drop
                dropWidth = getComputedStyle(this, null).getPropertyValue("width");
                dropHeight = getComputedStyle(this, null).getPropertyValue("height");

                // calculate relative coordinates of click
                // logic: click coordinates relative to page - parent's position relative to page - half of self height/width to make it controllable from the center
                x = e.pageX - this.offsetLeft - (parseInt(dropWidth, 10) / 2);
                y = e.pageY - this.offsetTop - (parseInt(dropHeight, 10) / 2) - 30;

                // position drop and animate
                drop.style.top = y + 'px';
                drop.style.left = x + 'px';
                drop.className += ' animate';
                e.stopPropagation();

            }
        }
   
    function datapass() {
    let image = $('#cuctomeimage')[0].files[0];
    let _token = $('#token').val();
    let title = $('#title').val();
    let id = $('#id').val();

    let current_image = $('#current_image').val();
    var myEditor = document.querySelector('#editor-container')
    var html = myEditor.children[0].innerHTML
    if (title == '' || title == null || title == ' ') {
        swal.fire(
            'Alert!',
            'Please mention title first',
            'error'
        );
    } else if (html == ' ' || html == null || html == '<p><br></p>') {
        swal.fire(
            'Alert!',
            'Please mention About us',
            'error'
        );
    } else {
       
        var formData = new FormData();
        formData.append('_token' , _token );
        formData.append('title' , title );
        formData.append('id' , id );
        formData.append('content' , html );                                                                                      
        formData.append('current_image' , current_image );                                          
        image===undefined?"" : formData.append('image' , image );
        $.ajax({
            type: "POST",
            enctype: 'multipart/form-data',
            url: "{{  route('updateblog') }}", // Using route helper to get the route URL
            data: formData,
            processData: false,
            contentType: false,
            cache: false,

            success: function (response) {

                window.location.href = "/admin/blogs";

                Swal.fire(
                    'Success Alert!', 'Blog updated.', 'success'
                )

            }
        });
        
    }
}
   </script>
@endpush
