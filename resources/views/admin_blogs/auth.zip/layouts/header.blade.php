<nav class="navbar navbar-expand-lg main-navbar sticky bg-dark">
    <div class="form-inline mr-auto">
        <ul class="navbar-nav mr-3">
            <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg collapse-btn"> <i data-feather="menu"></i></a></li>
            <li>
                
            </li>
        </ul>
    </div>
    <ul class="navbar-nav navbar-right">
        <li class="dropdown"><a href="#" data-toggle="dropdown"
                class="nav-link dropdown-toggle nav-link-lg nav-link-user">
                <span>{{ Auth::user()->name }}</span> <img alt="image" src="{{ asset('admin-assets/img/user.png') }}" class="user-img-radious-style">
                <span class="d-sm-none d-lg-inline-block"></span>
            </a>
            <div class="dropdown-menu dropdown-menu-right pullDown bg-dark">
                <a href="#" class="dropdown-item has-icon text-danger" onclick="event.preventDefault();  document.getElementById('logout-form').submit();"> <i
                        class="fas fa-sign-out-alt"></i>
                    Logout
                </a>
                <form id="logout-form" method="POST" class="d-none" action="{{route('logout')}}">
                    <input type="hidden" name="_token" value="{{ csrf_token() }}" autocomplete="off">                                    </form>
            </div>
        </li>
    </ul>
</nav>
